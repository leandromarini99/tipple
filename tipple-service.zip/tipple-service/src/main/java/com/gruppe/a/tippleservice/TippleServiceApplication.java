package com.gruppe.a.tippleservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TippleServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TippleServiceApplication.class, args);
	}

}
