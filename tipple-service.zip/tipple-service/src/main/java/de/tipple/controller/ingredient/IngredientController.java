package de.tipple.controller.ingredient;

import de.tipple.model.ingredient.Ingredient;
import de.tipple.service.ingredient.IngredientService;
import org.reactivestreams.Publisher;
import org.springframework.data.mongodb.core.aggregation.ArrayOperators;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.Optional;

@RestController
@RequestMapping(value = "/ingredients", produces = MediaType.APPLICATION_JSON_VALUE)
public class IngredientController {
  private final MediaType jSONMediaType = MediaType.APPLICATION_JSON;
  private final IngredientService ingredientService;

  public IngredientController(IngredientService ingredientService) {
    this.ingredientService = ingredientService;
  }
  @GetMapping
  Publisher<Ingredient> getAll() {
    return ingredientService.getIngredients();
  }
  @GetMapping("/{id}")
  Publisher<ResponseEntity<?>> getById(@PathVariable("id") String id) {
    return ingredientService.getIngredientById(id)
        .map(ingredient -> ResponseEntity.ok()
            .contentType(jSONMediaType).build());
  }

  @PostMapping
  Publisher<ResponseEntity<Ingredient>> create(@RequestBody Ingredient ingredient) {
    return ingredientService.create(ingredient)
        .map(ing-> ResponseEntity.created(URI.create("/ingredient/"+ing.getId()))
        .contentType(jSONMediaType).build());
  }

  @DeleteMapping("{id}")
  Publisher<ResponseEntity<Ingredient>> deleteById(@PathVariable("id") String id) {
    return ingredientService.delete(id).map(ingredient -> ResponseEntity.ok().contentType(jSONMediaType).build());
  }

  @PutMapping("/id")
  Publisher<ResponseEntity<Ingredient>> updateById(@PathVariable("id") String
                                                       id, @RequestBody Ingredient ingredient) {
    return Mono.just(ingredient)
        .flatMap(ing-> ingredientService.update(id, ing))
        .map(ing-> ResponseEntity.ok()
            .contentType(jSONMediaType)
            .build());
  }

}
