package de.tipple.controller;

import de.tipple.model.User;
import de.tipple.service.UserService;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

@Component
public class UserHTTPController {

  private final UserService userService;
  private static final MediaType jSONMediaType = MediaType.APPLICATION_JSON;
  private final HTTPResponseService<User> httpResponseService;
  public UserHTTPController(UserService userService, HTTPResponseService<User> httpResponseService) {
    this.userService = userService;
    this.httpResponseService = httpResponseService;
  }

  public Mono<ServerResponse> getById(ServerRequest request) {
    return httpResponseService.defaultSingleReadResponse(userService
        .getUserById(getIdFromPathVariable(request)));
  }

  public Mono<ServerResponse> getByEmail(ServerRequest request) {
    return httpResponseService.defaultSingleReadResponse(userService
        .findUserByEmail(getIdFromPathVariable(request)));
  }

  public Mono<ServerResponse> login(ServerRequest request) {
    Flux<Map<String, Object>> resMap =  request.bodyToFlux(User.class)
       .flatMap(userService::login);

    return Mono.from(resMap)
        .flatMap(map-> {
          if(map.get("userId").equals(""))
            return ServerResponse.status(401)
                .body(Mono.just(map),Map.class);
          else  return ServerResponse.ok().contentType(jSONMediaType)
              .body(Mono.just(map),Map.class);
        });
  }

  public Mono<ServerResponse> validate(ServerRequest request) {
    String email = getIdFromPathVariable(request);
    return Mono.from(userService.findUserByEmail(email)
        .flatMap(user -> ServerResponse.status(409)
            .body(Mono.just(email + " exists already"), String.class))
        .switchIfEmpty(ServerResponse.ok().body(Mono.just(email + " does not exist"), String.class)));
  }

  public Mono<ServerResponse> getUsers(ServerRequest request) {
    return httpResponseService
        .defaultMultiReadResponse(userService.getUsers());
  }

  public Mono<ServerResponse> deleteById(ServerRequest request) {
    return httpResponseService.defaultSingleReadResponse(userService
        .delete(getIdFromPathVariable(request)));
  }

  public Mono<ServerResponse> updateById( ServerRequest request) {
    Flux<User> userFlux = request.bodyToFlux(User.class)
        .flatMap(user -> userService
            .update(getIdFromPathVariable(request), user));
    return httpResponseService.defaultSingleReadResponse(userFlux);
  }

  public Mono<ServerResponse> create(ServerRequest request) {
    Flux<User> userFlux = request.bodyToFlux(User.class)
        .flatMap(userService::create);
    var url = new AtomicReference<>("");
    userFlux.flatMap(user -> {
      url.set("/users/" +user.getId());
      return null;
    });
    return httpResponseService.defaultWriteResponse(userFlux, url.get());
  }

  private static String getIdFromPathVariable(ServerRequest request) {
    return request.pathVariable("id");
  }

}
