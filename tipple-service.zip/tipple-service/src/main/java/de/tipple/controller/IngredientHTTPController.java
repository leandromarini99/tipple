package de.tipple.controller;

import de.tipple.model.Ingredient;
import de.tipple.service.IngredientService;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.concurrent.atomic.AtomicReference;

@Component
public class IngredientHTTPController {
  private static final MediaType jSONMediaType = MediaType.APPLICATION_JSON;
  private final IngredientService ingredientService;
  private final HTTPResponseService<Ingredient> httpResponseService;

  public IngredientHTTPController(IngredientService ingredientService,
                                  HTTPResponseService<Ingredient> httpResponseService) {
    this.ingredientService = ingredientService;
    this.httpResponseService = httpResponseService;
  }

  private static String getIdFromPathVariable(ServerRequest request) {
    return request.pathVariable("id");
  }

  public Mono<ServerResponse> getById(ServerRequest request) {
    return httpResponseService.defaultSingleReadResponse(ingredientService
        .getIngredientById(getIdFromPathVariable(request)));
  }

  public Mono<ServerResponse> getIngredients(ServerRequest request) {
    return ServerResponse.ok()
        .contentType(jSONMediaType)
        .body(Flux.from(ingredientService.getIngredients()), Ingredient.class);
  }

  public Mono<ServerResponse> deleteById(ServerRequest request) {
    return httpResponseService
        .defaultSingleReadResponse(ingredientService
            .delete(getIdFromPathVariable(request)));
  }

  public Mono<ServerResponse> updateById(ServerRequest request) {
    Flux<Ingredient> ingredientFlux = request.bodyToFlux(Ingredient.class)
        .flatMap(ingredient -> ingredientService
            .update(getIdFromPathVariable(request), ingredient));
    return httpResponseService.defaultSingleReadResponse(ingredientFlux);
  }

  public Mono<ServerResponse> create(ServerRequest request) {
    Flux<Ingredient> ingredientFlux = request.bodyToFlux(Ingredient.class)
        .flatMap(ingredientService::create);
    var url = new AtomicReference<>("");
    ingredientFlux.flatMap(ingredient -> {
      url.set("/ingredients/" + ingredient.getId());
      return null;
    });
    return httpResponseService.defaultWriteResponse(ingredientFlux, url.get());
  }

}
