package de.tipple.controller;

import org.reactivestreams.Publisher;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.net.URI;
@Component
public class HTTPResponseService<T> {

  protected Mono<ServerResponse> defaultWriteResponse( Publisher<T> tPublisher, String url) {
    return Mono.from(tPublisher)
        .flatMap(type -> ServerResponse
            .created(URI.create(url))
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(type), type.getClass()));
  }

  protected Mono<ServerResponse> defaultSingleReadResponse(Publisher<T> tPublisher) {
    return Mono.from(tPublisher).flatMap(type ->
        ServerResponse.ok()
            .body(Mono.just(type),type.getClass()))
        .switchIfEmpty(ServerResponse.notFound().build());
  }
  protected Mono<ServerResponse> defaultMultiReadResponse(Publisher<T> tPublisher) {
    return Mono.from(tPublisher)
        .flatMap(type ->
            ServerResponse.ok()
                .body(Flux.from(tPublisher), type.getClass()))
        .switchIfEmpty(ServerResponse.notFound().build());
  }
}
