package de.tipple.controller.user;

import de.tipple.model.user.User;
import de.tipple.service.user.UserService;
import org.reactivestreams.Publisher;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.net.URI;


//@RestController
//@RequestMapping(value ="/users", produces = MediaType.APPLICATION_JSON_VALUE)
public class UserRestController {

//  private static final MediaType mediaType = MediaType.APPLICATION_JSON;
//  private final UserService userService;
//
//  public UserRestController(UserService userService) {
//    this.userService = userService;
//  }
//
//  @GetMapping
//  Publisher<User> getAll() {
//    return userService.getAll();
//  }
//
//  @GetMapping("/{id}")
//  Publisher<User> getUserById(@PathVariable("id") String id) {
//    return userService.get(id);
//  }
//
//  @PostMapping
//  Publisher<ResponseEntity<User>> create(@RequestBody User user) {
//    return userService.create(user)
//        .map(u-> ResponseEntity.created(URI.create("/users/"+ u.getId()))
//            .contentType(mediaType)
//        .build());
//  }
//
//  @DeleteMapping("/{id}")
//  Publisher<User> deleteById(@PathVariable("id") String id) {
//    return userService.delete(id);
//  }
//
//  @PutMapping("/{id}")
//  Publisher<ResponseEntity<User>> updateById(@PathVariable String id, @RequestBody User user) {
//    return Mono
//        .just(user)
//        .flatMap(u -> userService.update(id, u))
//        .map(u-> ResponseEntity
//            .ok().contentType(mediaType).build());
//  }

}
