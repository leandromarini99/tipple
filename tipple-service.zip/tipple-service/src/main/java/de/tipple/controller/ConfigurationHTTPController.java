package de.tipple.controller;

import de.tipple.model.Configuration;
import de.tipple.service.ConfigurationService;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.concurrent.atomic.AtomicReference;

@Component
public class ConfigurationHTTPController {
  private final ConfigurationService configurationService;
  private final HTTPResponseService<Configuration> httpResponseService;

  public ConfigurationHTTPController(ConfigurationService configurationService,
                                     HTTPResponseService<Configuration> httpResponseService) {
    this.configurationService = configurationService;
    this.httpResponseService = httpResponseService;
  }

  public Mono<ServerResponse> getConfigurationsByUserId(ServerRequest request) {
    return httpResponseService.defaultMultiReadResponse(configurationService
        .getConfigsByUser(getIdFromPathVariable(request)));
  }

  public Mono<ServerResponse> getPublicConfigurations(ServerRequest request) {
    return httpResponseService
        .defaultMultiReadResponse(configurationService.getPublicConfigurations());
  }

  public Mono<ServerResponse> getCarts(ServerRequest request) {
    return httpResponseService
        .defaultMultiReadResponse(configurationService.getCarts());
  }

  public Mono<ServerResponse> getCartByUser(ServerRequest request) {
    return httpResponseService
        .defaultMultiReadResponse(configurationService
            .getCartByUser(getIdFromPathVariable(request)));
  }

  public Mono<ServerResponse> getConfigurationById(ServerRequest request) {
    return httpResponseService.defaultSingleReadResponse(configurationService
        .getConfigurationsById(getIdFromPathVariable(request)));
  }

  public Mono<ServerResponse> deleteById(ServerRequest request) {
    return httpResponseService.defaultSingleReadResponse(configurationService
        .delete(getIdFromPathVariable(request)));
  }

  public Mono<ServerResponse> updateById(ServerRequest request) {
    Flux<Configuration> config = request.bodyToFlux(Configuration.class)
        .flatMap(conf -> configurationService.update(getIdFromPathVariable(request), conf));
    return httpResponseService.defaultSingleReadResponse(config);
  }

  public Mono<ServerResponse> create(ServerRequest request) {
    Flux<Configuration> flux = request.bodyToFlux(Configuration.class)
        .flatMap(configurationService::create);
    var url = new AtomicReference<>("");
    flux.flatMap(configuration -> {
          url.set("/configurations/" + configuration.getId());
          return null;
        }
    );
    return httpResponseService.defaultWriteResponse(flux, url.get());
  }

  private static String getIdFromPathVariable(ServerRequest request) {
    return request.pathVariable("id");
  }
}
