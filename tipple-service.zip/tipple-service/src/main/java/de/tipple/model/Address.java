package de.tipple.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Address {
  private String street;
  private String houseNumber;
  private int zipCode;
  private String town;

  public Address() {
  }

  public Address(String street, String houseNumber, int zipCode, String town) {
    this.street = street;
    this.houseNumber = houseNumber;
    this.zipCode = zipCode;
    this.town = town;
  }

  public String getTown() {
    return town;
  }

  public int getZipCode() {
    return zipCode;
  }

  public String getStreet() {
    return street;
  }

  public String getHouseNumber() {
    return houseNumber;
  }
}
