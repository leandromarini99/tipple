package de.tipple.service;

import de.tipple.PasswordHandler;
import de.tipple.model.User;
import de.tipple.repository.UserRepository;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
@Configuration
public class UserService {

  private final UserRepository userRepository;
  private final PasswordHandler passwordHandler;


  public UserService(UserRepository userRepository, PasswordHandler passwordHandler) {
    this.userRepository = userRepository;
    this.passwordHandler = passwordHandler;
  }

  public Flux<User> getUsers() {
    return userRepository.findAll();
  }

  public Mono<User> getUserById(String id) {
    return userRepository.findById(id);
  }

  public Mono<User> update(String id, User postedUser) {
    return userRepository.findById(id)
        .map(user -> {
          postedUser.setId(user.getId());
          if (postedUser.getPassword().equals(user.getPassword())) {
            return new User(postedUser);
          }else if (passwordHandler.encrypt(postedUser.getPassword()).equals(user.getPassword())){
            return new User(postedUser);
          }else {
            postedUser.setPassword(passwordHandler.encrypt(postedUser.getPassword()));
            return new User(postedUser);
          }
        })
        .flatMap(userRepository::save);
  }

  public Mono<User> delete(String id) {
    return userRepository.findById(id)
        .flatMap(user -> userRepository
            .deleteById(user.getId())
            .thenReturn(user));
  }

  public Mono<User> create(User user) {
    user.setId(UUID.randomUUID().toString());
    user.setPassword(passwordHandler.encrypt(user.getPassword()));
    return userRepository.save(user);
  }

  public Flux<User> findUserByEmail(String email) {
  return userRepository.findAll()
        .filter(user -> user.getEmail().equals(email))
      .doOnNext(Mono::just);

  }

  public Flux<Map<String, Object>> login(User loginUser) {
    Map<String, Object> verificationMap = new ConcurrentHashMap<>();
    verificationMap.put("verified",false);
    verificationMap.put("userId", "");
    return userRepository.findAll()
        .filter(user ->
            user.getEmail().equals(loginUser.getEmail()))
        .flatMap(user -> {
          user.setPassword(passwordHandler.decrypt(user.getPassword()));
          System.err.println("Saved password: "+ user.getPassword()
              +" <-> Posted password: "+ loginUser.getPassword());
          if (user.getPassword().equals(loginUser.getPassword())) {
            verificationMap.put("verified", true);
            verificationMap.put("userId", user.getId());
            verificationMap.put("firstName", user.getFirstName());
            verificationMap.put("lastName", user.getLastName());
          }
          return Flux.just(verificationMap);
        }).switchIfEmpty(Flux.just(verificationMap));
  }


}

