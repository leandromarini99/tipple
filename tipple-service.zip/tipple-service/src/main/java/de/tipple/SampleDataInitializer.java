package de.tipple;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.tipple.model.Ingredient;
import de.tipple.model.User;
import de.tipple.repository.ConfigurationRepository;
import de.tipple.repository.IngredientRepository;
import de.tipple.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Component
@org.springframework.context.annotation.Profile("Development")
public class SampleDataInitializer implements ApplicationListener<ApplicationReadyEvent> {
  @Autowired
  public final UserRepository repository;
  @Autowired
  public final IngredientRepository ingredientRepository;
  @Autowired
  final ConfigurationRepository configurationRepository;
  private final PasswordHandler passwordHandler;

  public SampleDataInitializer(UserRepository repository,
                               IngredientRepository ingredientRepository,
                               ConfigurationRepository configurationRepository, PasswordHandler passwordHandler) {
    this.repository = repository;
    this.ingredientRepository = ingredientRepository;
    this.configurationRepository = configurationRepository;
    this.passwordHandler = passwordHandler;


  }

  @Override
  public void onApplicationEvent(ApplicationReadyEvent event) {

    repository.deleteAll().thenMany(
        Flux
            .fromIterable(addUsers())
            .map(User::new)
            .flatMap(user -> {
              user.setPassword(passwordHandler.encrypt(user.getPassword()));
              return repository.save(user);
            })
    ).thenMany(repository.findAll())
        .subscribe(user -> System.err.println("Saving User: " + user.getId()));

    ingredientRepository.deleteAll().thenMany(
        Flux
            .fromIterable(addIngredients())
            .map(Ingredient::new)
            .flatMap(ingredientRepository::save)
    ).thenMany(ingredientRepository.findAll())
        .subscribe(ing -> System.err.println("Saving Ingredient: " + ing.getId()));

    configurationRepository.deleteAll().subscribe();

  }

  private List<User> addUsers() {
    var mapper = new ObjectMapper();
    TypeReference<List<User>> typeReference = new TypeReference<>() {
    };
    var inputStream = TypeReference.class.getResourceAsStream("/json/users.json");
    try {
      return mapper.readValue(inputStream, typeReference);
    } catch (IOException e) {
      System.err.println("Unable to save users: " + e.getMessage());
    }
    return new ArrayList<>();
  }

  private List<Ingredient> addIngredients() {
    var mapper = new ObjectMapper();
    TypeReference<List<Ingredient>> typeReference = new TypeReference<>() {
    };
    var inputStream = TypeReference.class.getResourceAsStream("/json/ingredients.json");
    try {
      return mapper.readValue(inputStream, typeReference);
    } catch (IOException e) {
      System.err.println("Unable to save ingredients: " + e.getMessage());
    }
    return new ArrayList<>();
  }

}
